<?php
/*
Plugin Name: Pacity
Plugin URI: https://bukediexpress.com/
Description: Pacity plugin helps a WordPress user to set the opacity of the WordPress website for a given number of days.
Version: 1.0
Author: Ayeet Daniel Onyanga
Author URI: https://onyangagroup.com/
License: GPL2
*/

// Function to add custom CSS for opacity based on the number of days
function pacity_add_opacity() {
    // Set the total number of days for the opacity to fade
    $total_days = 5; // You can change this to any number of days you want

    // Get the start date from the WordPress options table
    $start_date = get_option('pacity_start_date');

    // If no start date is set, initialize it with today's date
    if (!$start_date) {
        $start_date = current_time('Y-m-d');
        update_option('pacity_start_date', $start_date);
    }

    // Calculate the number of days that have passed since the start date
    $today = new DateTime(current_time('Y-m-d'));
    $start = new DateTime($start_date);
    $interval = $today->diff($start)->days;

    // Calculate the opacity based on how many days have passed
    $opacity = max(1 - ($interval / $total_days), 0); // Ensure opacity doesn't go below 0

    // Output the CSS that sets the opacity of the body tag
    echo "
    <style>
        body {
            opacity: $opacity;
            transition: opacity 1s ease-in-out;
        }
    </style>
    ";
}

// Hook the function to add the CSS into the <head> section of the site
add_action('wp_head', 'pacity_add_opacity');

// Create the Pacity settings page in the WordPress admin
function pacity_add_settings_page() {
    add_options_page(
        'Pacity Settings',
        'Pacity',
        'manage_options',
        'pacity',
        'pacity_render_settings_page'
    );
}
add_action('admin_menu', 'pacity_add_settings_page');

// Render the settings page content
function pacity_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Pacity Plugin Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('pacity_options_group');
            do_settings_sections('pacity');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register the settings
function pacity_register_settings() {
    register_setting('pacity_options_group', 'pacity_fade_days');
    add_settings_section('pacity_main_section', 'Main Settings', null, 'pacity');
    add_settings_field('pacity_fade_days_field', 'Number of Days for Opacity Fade:', 'pacity_fade_days_field_render', 'pacity', 'pacity_main_section');
}
add_action('admin_init', 'pacity_register_settings');

// Render the number of days input field
function pacity_fade_days_field_render() {
    $value = get_option('pacity_fade_days', 5); // Default is 5 days
    echo '<input type="number" name="pacity_fade_days" value="' . esc_attr($value) . '" />';
}


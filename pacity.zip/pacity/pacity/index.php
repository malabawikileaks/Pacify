<?php
// Silence is golden always.
?>